# Chapter 2 Hyper Text Markup Language (HTML)

These examples demonstrate the HyperText Markup Langauge and how it can be used to control the layout and appearance of items on a web page. Later examples show how an HTML page can display other media, including images and sound. 