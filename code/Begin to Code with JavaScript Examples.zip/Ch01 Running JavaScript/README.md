# Chapter 1 Running JavaScript

There is only one example in this folder. It is the Hello.html page that contains the "secret" JavaScript program.